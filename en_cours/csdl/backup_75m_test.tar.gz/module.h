#ifndef H_MODULE
#define H_MODULE

#define LIGNES 1081 // nb de lignes
#define COLONNES 1161 // nb de colonnes
#define LIGNES_75 1000 // nb de lignes
#define COLONNES_75 1000 // nb de colonnes
#define DEZOOM_X 859
#define DEZOOM_Y 800    // 859x800 environ
//#define REP "/home/fabien/Documents/test/csdl/75m"
#define NMAX 50

typedef struct {
        double metre;
        int estInonde;
} Point;

typedef struct {
    void * pt_tab;
    void * pt_ecran;
    void * pt_surface_75;
    void * pt_zoom;
    int done;
} data_map; //struct pour le thread

#endif // H_MODULE
