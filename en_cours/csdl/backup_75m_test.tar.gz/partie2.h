#ifndef H_PARTIE2
#define H_PARTIE2

#include "module.h"
#include <SDL/SDL.h>
#include <SDL/SDL_rotozoom.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <pthread.h>

extern void zoom(int posx, int posy, int val_zoom, SDL_Surface *tempo, SDL_Surface *ecran);

extern void pause(Point **tabPt, SDL_Rect TBoutton, SDL_Surface *surface_1000,SDL_Surface *surface_75, SDL_Surface *ecran);

extern void getPixelColor(SDL_Rect position, SDL_Surface *surface, Uint8 *r, Uint8 *g, Uint8 *b);

extern void remplirFrance(Point **tab, SDL_Surface *sortie, SDL_Surface *ecran, int x, int y, int type);

extern SDL_Rect boutton(SDL_Surface *ecran, TTF_Font *police);

extern void sdl_ini(Point **tabPt);

extern void * fichier_dif(data_map * data_75);

#endif // H_PARTIE2
